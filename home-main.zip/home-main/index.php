<?php
header('HTTP/1.0 404 Not Found');
?>
<h1>invalid request, OWS Server</h1>
